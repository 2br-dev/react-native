try {
    Typekit.load({
        async: true
    });
}
catch(e) {

}
