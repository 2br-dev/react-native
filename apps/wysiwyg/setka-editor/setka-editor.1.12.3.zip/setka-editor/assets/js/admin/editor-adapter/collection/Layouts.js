
module.exports = Backbone.Collection.extend({

});
