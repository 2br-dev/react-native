<?php
namespace Setka\Editor\Entries;

class SetkaEditorFilePostType {

	const NAME = 'setka_editor_file';
}
