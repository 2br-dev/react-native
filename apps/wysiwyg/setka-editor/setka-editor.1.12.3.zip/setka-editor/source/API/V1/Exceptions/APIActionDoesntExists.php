<?php
namespace Setka\Editor\API\V1\Exceptions;

class APIActionDoesntExists extends \Exception {

}
