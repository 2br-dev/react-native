<?php
namespace Setka\Editor\API\V1\Prototypes;

/**
 * Similar to ActionInterface but called from Actions.
 */
interface HelperInterface extends ActionInterface {

}
