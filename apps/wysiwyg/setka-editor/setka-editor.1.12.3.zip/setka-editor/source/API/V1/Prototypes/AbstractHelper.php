<?php
namespace Setka\Editor\API\V1\Prototypes;

abstract class AbstractHelper extends AbstractAction implements HelperInterface {

}
