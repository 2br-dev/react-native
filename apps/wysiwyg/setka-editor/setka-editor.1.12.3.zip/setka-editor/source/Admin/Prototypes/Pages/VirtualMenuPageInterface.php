<?php
namespace Setka\Editor\Admin\Prototypes\Pages;

interface VirtualMenuPageInterface {

}
