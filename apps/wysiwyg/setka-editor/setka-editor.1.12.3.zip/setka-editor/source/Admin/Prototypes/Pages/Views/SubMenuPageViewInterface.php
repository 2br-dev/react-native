<?php
namespace Setka\Editor\Admin\Prototypes\Pages\Views;

interface SubMenuPageViewInterface extends PageViewInterface {

}