<?php
namespace Setka\Editor\Admin\Prototypes\AJAX;

abstract class Loader {

	public static function registerActions() {

	}
}
