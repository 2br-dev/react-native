<?php
namespace Setka\Editor\Admin\Migrations\Exceptions;

class MissedCurrentVersionException extends \Exception {

}
