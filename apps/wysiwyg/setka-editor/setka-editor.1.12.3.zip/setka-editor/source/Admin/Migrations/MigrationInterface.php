<?php
namespace Setka\Editor\Admin\Migrations;

interface MigrationInterface {

    public function up();
}
