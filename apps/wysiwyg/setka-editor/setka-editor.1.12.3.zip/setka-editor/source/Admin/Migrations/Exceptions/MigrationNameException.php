<?php
namespace Setka\Editor\Admin\Migrations\Exceptions;

class MigrationNameException extends \Exception {

}
