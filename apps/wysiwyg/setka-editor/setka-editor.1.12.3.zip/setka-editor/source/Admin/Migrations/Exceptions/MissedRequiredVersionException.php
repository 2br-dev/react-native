<?php
namespace Setka\Editor\Admin\Migrations\Exceptions;

class MissedRequiredVersionException extends \Exception {

}
