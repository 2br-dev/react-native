<?php
namespace Setka\Editor\Admin\User\Capabilities\Prototypes;

interface Capability {
	/**
	 * This class must implements const NAME with capability name.
	 */
}
