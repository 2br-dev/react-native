<?php
namespace Setka\Editor\Admin\Service\ContinueExecution;

class OutOfTimeException extends \Exception {

}
