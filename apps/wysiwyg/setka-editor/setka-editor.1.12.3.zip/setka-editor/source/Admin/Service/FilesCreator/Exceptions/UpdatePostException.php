<?php
namespace Setka\Editor\Admin\Service\FilesCreator\Exceptions;

/**
 * Error during post updating.
 */
class UpdatePostException extends \Exception {

}
