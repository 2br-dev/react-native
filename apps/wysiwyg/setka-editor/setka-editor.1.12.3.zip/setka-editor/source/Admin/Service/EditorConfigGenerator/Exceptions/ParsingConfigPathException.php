<?php
namespace Setka\Editor\Admin\Service\EditorConfigGenerator\Exceptions;

/**
 * Errors on parsing path.
 */
class ParsingConfigPathException extends \Exception {

}
