<?php
namespace Setka\Editor\Admin\Service\FilesManager\Exceptions;

class SyncDisabledByUseException extends \Exception {

}
