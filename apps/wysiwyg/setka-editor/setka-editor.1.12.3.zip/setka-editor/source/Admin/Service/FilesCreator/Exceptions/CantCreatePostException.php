<?php
namespace Setka\Editor\Admin\Service\FilesCreator\Exceptions;

/**
 * Error during post creating.
 */
class CantCreatePostException extends \Exception {

}
