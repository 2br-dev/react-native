<?php
namespace Setka\Editor\Admin\Service\EditorConfigGenerator\Exceptions;

/**
 * Can't read the file content for selected config.
 */
class ReadingConfigFileException extends \Exception {

}
