<?php
namespace Setka\Editor\Admin\Service\FilesSync\Exceptions;

class OriginUrlWithoutPathException extends \Exception {

}
