<?php
namespace Setka\Editor\Admin\Service\FilesCreator\Exceptions;

/**
 * Error during post meta updating.
 */
class CantCreateMetaException extends \Exception {

}
