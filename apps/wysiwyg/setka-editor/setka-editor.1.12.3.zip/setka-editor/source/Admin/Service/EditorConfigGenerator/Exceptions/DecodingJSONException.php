<?php
namespace Setka\Editor\Admin\Service\EditorConfigGenerator\Exceptions;

/**
 * Errors while decoding JSON from string. You can get error from json_last_error().
 */
class DecodingJSONException extends \Exception {

}
