<?php
namespace Setka\Editor\Admin\Service\SetkaAPI;

class Endpoints {

	const API = 'https://editor.setka.io';
	const API_DEV = 'http://editor-dev.setka.io';
}
