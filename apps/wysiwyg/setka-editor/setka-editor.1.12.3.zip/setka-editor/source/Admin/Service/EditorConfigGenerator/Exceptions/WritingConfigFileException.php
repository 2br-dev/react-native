<?php
namespace Setka\Editor\Admin\Service\EditorConfigGenerator\Exceptions;

/**
 * If filesystem cant write JSON string into file on disk.
 */
class WritingConfigFileException extends \Exception {

}
