<?php
namespace Setka\Editor\Admin\Service\EditorConfigGenerator\Exceptions;

/**
 * Error on JSON encoding from variable to string.
 */
class EncodingJSONException extends \Exception {

}
