<?php
namespace Setka\Editor\Admin\Service\FilesSync\Exceptions;

class CantRelocateDownloadedFileException extends \Exception {

}
