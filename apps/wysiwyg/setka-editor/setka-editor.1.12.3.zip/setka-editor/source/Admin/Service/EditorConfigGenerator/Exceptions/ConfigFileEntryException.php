<?php
namespace Setka\Editor\Admin\Service\EditorConfigGenerator\Exceptions;

/**
 * If config in DB was not found.
 */
class ConfigFileEntryException extends \Exception {

}
