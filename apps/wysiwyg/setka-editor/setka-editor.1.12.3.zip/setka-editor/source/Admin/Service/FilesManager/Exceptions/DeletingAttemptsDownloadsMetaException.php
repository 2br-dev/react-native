<?php
namespace Setka\Editor\Admin\Service\FilesManager\Exceptions;

class DeletingAttemptsDownloadsMetaException extends \Exception {

}
