<?php
namespace Setka\Editor\Admin\Service\FilesManager\Exceptions;

class FailureOptionException extends \Exception {

}
