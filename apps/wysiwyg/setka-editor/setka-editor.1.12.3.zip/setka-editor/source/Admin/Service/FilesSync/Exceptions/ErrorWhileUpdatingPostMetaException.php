<?php
namespace Setka\Editor\Admin\Service\FilesSync\Exceptions;

class ErrorWhileUpdatingPostMetaException extends \Exception {

}
