<?php
namespace Setka\Editor\Admin\MetaBoxes\InvitationToRegister;

use Setka\Editor\Plugin;
use Setka\Editor\Admin\Prototypes\MetaBoxes\AbstractMetaBox;

class InvitationToRegisterMetaBox extends AbstractMetaBox
{
    public function __construct()
    {
        $this
            ->setId(Plugin::_NAME_.'_invitation_to_registerMetaBox')
            ->setTitle(_x('Setka Editor Registration', 'MetaBox title.', Plugin::NAME))
            ->setContext('side')
            ->setView(new InvitationToRegisterView());
    }
}
